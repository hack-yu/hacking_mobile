
#import <UIKit/UIKit.h>
#import "ExerciseViewController.h"

@interface MemoryManagementVC : ExerciseViewController
@end
