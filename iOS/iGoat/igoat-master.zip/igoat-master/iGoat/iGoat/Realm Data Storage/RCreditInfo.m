
#import "RCreditInfo.h"

@implementation RCreditInfo

@end
