
#import "ExerciseViewController.h"

@interface RealmExerciseViewController : ExerciseViewController
    @property (nonatomic, weak) IBOutlet UITextField *creditNameTextField;
    @property (nonatomic, weak) IBOutlet UITextField *creditNumberTextField;
    @property (nonatomic, weak) IBOutlet UITextField *creditCVVTextField;
@end
