
#import "ExerciseViewController.h"

@interface URLSchemeAttackExerciseVC : ExerciseViewController
@property (nonatomic, weak)  IBOutlet UITextField *mobileNumberTxtField;
@property (nonatomic, weak)  IBOutlet UITextField *messageTxtField;
@end
