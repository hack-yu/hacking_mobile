//
//  BinaryPatchingVC.h
//  iGoat
//
//  Created by Swaroop Yermalkar on 20/06/17.
//  Copyright © 2017 KRvW Associates, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ExerciseViewController.h"

@interface BinaryPatchingVC : ExerciseViewController

@end
