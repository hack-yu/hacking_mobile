#import <Foundation/Foundation.h>

@interface NSURL (Parameters)
    -(NSDictionary *)parmetersInfo;
@end
