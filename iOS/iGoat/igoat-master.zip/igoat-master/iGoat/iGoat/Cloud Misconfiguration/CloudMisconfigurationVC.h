#import "ExerciseViewController.h"

@interface CloudMisconfigurationVC : ExerciseViewController

@end
