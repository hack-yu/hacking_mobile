
#import "ExerciseViewController.h"

@interface SocialEngineeringVC : ExerciseViewController
@property (nonatomic, weak)  IBOutlet UITextField *nameTxtField;
@property (nonatomic, weak)  IBOutlet UITextField *passwordTxtField;
@end
