
#import <UIKit/UIKit.h>
#import "ExerciseViewController.h"

@interface YAPExcersizeViewController : ExerciseViewController
    @property (nonatomic,weak) IBOutlet UITextField *emailTextField;
    @property (nonatomic,weak) IBOutlet UITextField *passwordTextField;
@end
