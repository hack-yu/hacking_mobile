//
//  SecureUserDefaultsViewController.h
//  iGoat
//
//  Created by tilak kumar on 8/23/17.
//  Copyright © 2017 KRvW Associates, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ExerciseViewController.h"

@interface SecureUserDefaultsViewController : ExerciseViewController

@end
