

#import "ExerciseViewController.h"

@interface BinaryCookiesExerciseViewController : ExerciseViewController
@property (nonatomic, weak)  IBOutlet UITextField *nameTxtField;
@property (nonatomic, weak)  IBOutlet UITextField *sessionTxtField;
@property (nonatomic, weak)  IBOutlet UITextField *csrfTxtField;
@end
