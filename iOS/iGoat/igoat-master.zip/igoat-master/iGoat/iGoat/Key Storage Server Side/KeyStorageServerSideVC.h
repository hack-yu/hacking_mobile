

#import <UIKit/UIKit.h>
#import "ExerciseViewController.h"

@interface KeyStorageServerSideVC : ExerciseViewController
@property (nonatomic, weak) IBOutlet UILabel *encryptedMessageLabel;
@property (nonatomic, weak) IBOutlet UITextField *encryptionTextField;
@end
