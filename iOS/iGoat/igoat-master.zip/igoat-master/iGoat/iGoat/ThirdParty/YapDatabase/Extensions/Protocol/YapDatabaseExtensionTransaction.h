#import <Foundation/Foundation.h>


@interface YapDatabaseExtensionTransaction : NSObject

/**
 * This class is abstract and has no public API.
 * See concrete implementations such as YapDatabaseViewTransaction, YapDatabaseSecondaryIndexTransaction, etc.
**/

@end
