#import "YDBCKRecordInfo.h"
#import "YapDatabaseCloudKitPrivate.h"


@implementation YDBCKRecordInfo

@synthesize databaseIdentifier;
@synthesize originalValues;

@synthesize keysToRestore;
@synthesize versionInfo;

@end
