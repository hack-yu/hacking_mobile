
#import <UIKit/UIKit.h>
#import "ExerciseViewController.h"

@interface CyrptoChallengeVC : ExerciseViewController

@end
