//
//  WebkitCacheExerciseViewController
//  iGoat
//
//  Created by Swaroop Yermalkar on 20/08/17.
//  Copyright © 2017 KRvW Associates, LLC. All rights reserved.
//

#import "ExerciseViewController.h"

@interface WebkitCacheExerciseViewController : ExerciseViewController

@end
