//
//  User+CoreDataClass.m
//  iGoat
//
//  Created by Swaroop Yermalkar on 19/05/17.
//  Copyright © 2017 KRvW Associates, LLC. All rights reserved.
//

#import "User+CoreDataClass.h"

@implementation User

@end
