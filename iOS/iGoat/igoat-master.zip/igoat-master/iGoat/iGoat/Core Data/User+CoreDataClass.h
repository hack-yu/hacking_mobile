//
//  User+CoreDataClass.h
//  iGoat
//
//  Created by Swaroop Yermalkar on 19/05/17.
//  Copyright © 2017 KRvW Associates, LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface User : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "User+CoreDataProperties.h"
