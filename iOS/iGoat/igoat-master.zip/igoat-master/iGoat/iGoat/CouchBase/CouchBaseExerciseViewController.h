
#import <UIKit/UIKit.h>
#import "ExerciseViewController.h"

@interface CouchBaseExerciseViewController : ExerciseViewController
@property (nonatomic,weak) IBOutlet UITextField *nameTextField;
@property (nonatomic,weak) IBOutlet UITextField *ageTextField;
@property (nonatomic,weak) IBOutlet UITextField *genderTextField;
@property (nonatomic,weak) IBOutlet UITextField *diseaseTextField;
@end
