#import "YDBCKAttachRequest.h"


@implementation YDBCKAttachRequest

@synthesize databaseIdentifier;
@synthesize record;

@synthesize shouldUploadRecord;

@end
